#include "linkedlist.h"
#include <stdlib.h>
#include <stdio.h>
//TODO Complete the code by giving the function definitions
void interactive(Node* head){

	char op[2];
	if (head){
		Node* ptr = head;

		do{
			printf("Enter d to move ptr the next element or q to quit\n");
			if(ptr){
				printf("ptr is pointing to the element %d\n", ptr->data);
				if(ptr->next){
					printf("Next element is %d\n", ptr->next->data);
				}
			}else{
				printf("ptr is NULL. Press q to exit");
			}

			scanf("%s", op);

			switch (op[0]){
				case 'd':
					if(ptr){
						ptr = ptr->next;
					}
					break;
				case 'q':
					printf("Exiting interactive mode\n");
					break;
				default:
					printf("Invalid option. Valid options are d (forward), q (quit) \n");
					break;
			}

		}while(op[0] != 'q');
		
	}else{
		printf("List is empty. Exiting ...\n");
	}

}


///////////////////////////////
void insert(Node** ref_to_head, int num){

  // TODO: Read the docstring above and complete the code
    Node* new_node = malloc(sizeof(Node));
    new_node->data = num;    
    new_node->next = *ref_to_head;
    *ref_to_head = new_node;
}

/////////////////////////////

Node* search(Node* head, int num){

  // TODO: Read the docstring above and complete the code
    Node* temp = head;
    while(temp != NULL){
        if(temp->data == num)
            return temp;   
        temp = temp->next;
    }
    return NULL;  
	


}
/////////////////////////////////

int delete(Node** ref_to_head, int num){

  Node* prev = NULL;
  // TODO: Read the docstring above and complete the code
    Node* temp = *ref_to_head;

	//head to be deleted
    if(temp != NULL && temp->data == num){
        *ref_to_head = temp->next;
        free(temp);
        return 1;
    }

	//deleting non head node by moving to next
    while(temp != NULL){
	if(temp->data==num){prev->next=temp->next;free(temp);return 1;
			}
        prev = temp;
        temp = temp->next;
	}
	return 0;//head is null  or data not found

}

//////////////////////////////////////////
void reverse(Node** ref_to_head){
	Node* head=*ref_to_head;
  // TODO: Read the docstring above and complete the code
   	Node* back=NULL;
	while(head!=NULL){
		Node* temp=head->next;//saving adress of 2
		head->next=back;//changing next to null
		back=head;//10 becomes back
		head=temp;//head becomes 2
	}
	*ref_to_head = back; 
}
/////////////////////////////////////////
void print(Node* head){
if(head == NULL){
        printf("-1\n");
        return;
    }
    Node* temp = head;
    while(temp != NULL){
        printf("%d ", temp->data);
        temp = temp->next;
    }
  printf("\n");
}
///////////////////
