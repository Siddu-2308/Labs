/*
 * Unit testing for the list library
 *
 */

// TODO: Add appropriate header files
#include "list.h"
#include <stdio.h>
#include <stdlib.h>

int testAppend(){
	// TODO: Complete the function
    List l = {NULL, 0, 0};
    append(&l, 10);
    append(&l, 20);
    append(&l, 30);

    if (l.curr_count != 3) return 1;
    if (l.array[0] != 10 || l.array[1] != 20 || l.array[2] != 30) return 1;

    free(l.array);
    return 0;
}
int testInsert(){
	// TODO: Complete the function
    List l = {NULL, 0, 0};
    append(&l, 10);
    append(&l, 30);
    insert(&l, 1, 20);  

    if (l.curr_count != 3) return 1;
    if (l.array[0] != 10 || l.array[1] != 20 || l.array[2] != 30) return 1;

    insert(&l, 0, 5);  
    if (l.array[0] != 5) return 1;

    insert(&l, l.curr_count, 40);  
    if (l.array[l.curr_count - 1] != 40) return 1;

    free(l.array);
    return 0;

}

int testDelete(){
	// TODO: Complete the function
	    List l = {NULL, 0, 0};
    append(&l, 10);
    append(&l, 20);
    append(&l, 30);
    append(&l, 40);

    delete(&l, 1);  
    if (l.curr_count != 3) return 1;
    if (l.array[1] != 30) return 1;

    delete(&l, 0);  
    if (l.array[0] != 30) return 1;

    delete(&l, l.curr_count - 1);  
    if (l.curr_count != 1) return 1;

    delete(&l, 0); 
    if (l.curr_count != 0 || l.array != NULL) return 1;

    return 0;
}

int testUpdate(){
	// TODO: Complete the function
    List l = {NULL, 0, 0};
    append(&l, 10);
    append(&l, 20);
    append(&l, 30);

    update(&l, 1, 99);
    if (l.array[1] != 99) return 1;

    if (update(&l, 5, 100) == 0) return 1;

    free(l.array);
    return 0;
}

///////////////////////////////////////
// Do not modify the functions below //
//////////////////////////////////////
int test(){
	int result = 1;

	if(testAppend()){
		printf("\tappend() failed\n");
		result = 0;
	}else{
		printf("append() passed\n");
	}

	if(testInsert()){
		printf("\tinsert() failed\n");
		result = 0;
	}else{
		printf("insert() passed\n");
	}

	if(testDelete()){
		printf("\tdelete() failed\n");
		result = 0;
	}else{
		printf("delete() passed\n");
	}

	if(testUpdate()){
		printf("\tupdate() failed\n");
		result = 0;
	}else{
		printf("update() passed\n");
	}

	return result;
}



int main(){

	printf("Running all test cases\n\n");
	if(test()){
		printf("\nAll test cases passed\n");
	}else{
		printf("\nSome test cases did not pass\n");
	}

	return 0;
}
