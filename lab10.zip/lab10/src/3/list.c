/*
 * Demo for realloc by implementing the list from python.
 * For documentation for each function, see list.h
 */

//TODO: Add appropriate header files as needed
#include "list.h"
#include <stdio.h>
#include <stdlib.h>
/*
 * Helper function to grow a list. 
 */

int grow(List* l){
	// TODO: Complete the function
	if (l == NULL){return 1;}

    if (l->max_count == 0) {
        l->max_count = 1;
        l->array = (int*)malloc(sizeof(int));
        if (l->array == NULL)
            return 1;
        return 0;
    }

    if (l->curr_count >= l->max_count) {
        int new_size = l->max_count * 2;
        int* new_array = (int*)realloc(l->array, new_size * sizeof(int));
        if (new_array == NULL)
            return 1;
        l->array = new_array;
        l->max_count = new_size;
    }

    return 0;

}

/*
 * Helper function to shrink a list
 *
 */

int shrink(List* l){
	// TODO: Complete the function
	if (l == NULL || l->array == NULL){return 1;}

    if (l->curr_count == 0) {
        free(l->array);
        l->array = NULL;
        l->max_count = 0;
        return 0;
    }

    if (l->curr_count <= l->max_count / 2 && l->max_count > 1) {
        int new_size = l->max_count / 2;
        int* new_array = (int*)realloc(l->array, new_size * sizeof(int));
        if (new_array == NULL){return 1;}
        l->array = new_array;
        l->max_count = new_size;
    }

    return 0;
}

/*
 * Update an element at a given location in the list
 *
 */
int update(List* l, int loc, int data)
{
	// TODO: Complete the function
    if (l == NULL || l->array == NULL){return 1;}

    if (loc < 0 || loc >= l->curr_count){return 1;}

    l->array[loc] = data;
    return 0;
}

/*
 * Remove an element at a given location in the list
 *
 */
int delete(List* l, int loc)
{
	// TODO: Complete the function
    if (l == NULL || l->array == NULL){return 1;}

    if (loc < 0 || loc >= l->curr_count){return 1;}

    for (int i = loc; i < l->curr_count - 1; i++)
       { l->array[i] = l->array[i + 1];}

    l->curr_count--;

    if (l->curr_count == 0) {
        free(l->array);
        l->array = NULL;
        l->max_count = 0;
        return 0;
    }

    if (shrink(l) != 0)
        return 1;

    return 0;
}

/*
 * Append an element at a given location in the list
 *
 */

int append(List* s, int data){

	// TODO: Complete the function
    if (s == NULL){return 1;}

    if (s->curr_count >= s->max_count) {
        if (grow(s) != 0)
            return 1;
    }

    s->array[s->curr_count] = data;
    s->curr_count++;

    return 0;


}

/*
 * Insert an element at a given location in the list
 *
 */

int insert(List* s, int loc, int data){
	// TODO: Complete the function
    if (s == NULL){return 1;}

    if (loc < 0 || loc > s->curr_count)
        {return 1;}

    if (s->curr_count >= s->max_count) {
        if (grow(s) != 0)
            {return 1;}
    }

    for (int i = s->curr_count; i > loc; i--)
        {s->array[i] = s->array[i - 1];}

    s->array[loc] = data;
    s->curr_count++;

    return 0;



}

