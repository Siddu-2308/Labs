/*
 * Implementation of Big Integer using list in C. For details on implementation
 * of the functions, see the docstring in bigint.h.
 *
 */

//TODO: Add appropriate header files
#include <stdio.h>
#include <stdlib.h>
#include "list.h"
#include "bigint.h"
// Number stored as a list with each storing 9 digits of the number
// Why 9 ? 9 = 32*log(2)/log(10)
#define POWNINE 1000000000
/*
 * Function to free memory used for a big integer
 */

void free_bigint(Bigint* bi_ptr){
	// TODO: Complete the function
	if (bi_ptr == NULL){
        	return;
	}

    if (bi_ptr->numbers != NULL) {
        if (bi_ptr->numbers->array != NULL){
            free(bi_ptr->numbers->array);
	}
        free(bi_ptr->numbers);
    }

    free(bi_ptr);
}

/*
 * Initializes a big integer
 *
 */
void initialize(Bigint* bi_ptr){
	// TODO: Complete the function
	if (bi_ptr == NULL){
        	return;
	}

    bi_ptr->numbers = (List*)malloc(sizeof(List));
    if (bi_ptr->numbers == NULL){
        return;
    }

    bi_ptr->numbers->array = NULL;
    bi_ptr->numbers->curr_count = 0;
    bi_ptr->numbers->max_count = 0;
    bi_ptr->sign = 1; // Default positive
}

/*
 * Check if two big integers are equal or not
 *
 */

int equal(Bigint* a_ptr, Bigint* b_ptr){
	// TODO: Complete the function
	if (a_ptr == NULL || b_ptr == NULL){
        	return -1;
	}

    if (a_ptr->sign != b_ptr->sign){
        return 1;
    }

    if(a_ptr->numbers == NULL || b_ptr->numbers == NULL){
	    return (a_ptr->numbers == b_ptr->numbers) ? 0 : 1;
	}
    if(a_ptr->numbers->curr_count != b_ptr->numbers->curr_count){
		return 1;
    }
    for(int i=0;i<a_ptr->numbers->curr_count;i++){
	    if(a_ptr->numbers->array[i] != b_ptr->numbers->array[i]){
		    return 1;
	    }
    }
    return 0; //equal
}


/*
 * Adds two big integer numbers and returns a pointer to the resulting sum
 *
 */
Bigint* add(Bigint* a_ptr, Bigint* b_ptr){
	// TODO: Complete the function
	if (a_ptr == NULL || b_ptr == NULL)
        	return NULL;

    Bigint* result = (Bigint*)malloc(sizeof(Bigint));
    if (result == NULL)
        return NULL;

    initialize(result);
    if(result->numbers == NULL){
	    free(result);
	    return NULL;
    }

    int carry = 0;
    int a_count = (a_ptr->numbers != NULL) ? a_ptr->numbers->curr_count : 0;
    int b_count = (b_ptr->numbers != NULL) ? b_ptr->numbers->curr_count : 0;
    int max_len = (a_count > b_count) ? a_count : b_count;

    for (int i = 0; i < max_len; i++) {
        int a_val = (i < a_count) ? a_ptr->numbers->array[i] : 0;
        int b_val = (i < b_count) ? b_ptr->numbers->array[i] : 0;

        long long sum = (long long)a_val + b_val + carry;
        carry = sum / POWNINE;
        int digit = sum % POWNINE;

        if (append(result->numbers, digit) == 1) {
            free_bigint(result);
            return NULL;
	}
    }
	if (carry > 0){
        	if(append(result->numbers, carry) == 1){
			free_bigint(result);
			return NULL;
		}
	}

    	result->sign = 1; // assuming only positive numbers supported
    	return result;
}

/*
 * Print a big integer passed as argument
 */

void print(Bigint* num_ptr){
	//TODO: Complete the function
	if (num_ptr == NULL || num_ptr->numbers == NULL || num_ptr->numbers->curr_count == 0){
        	printf("0\n");
		return;
	}

    if (num_ptr->sign < 0)
        printf("-");

    int n = num_ptr->numbers->curr_count;

    // Print most significant block normally, then pad others with leading zeros
    printf("%d", num_ptr->numbers->array[n - 1]);
    for (int i = n - 2; i >= 0; i--) {
        printf("%09d", num_ptr->numbers->array[i]);
    }
    printf("\n");
}

/*
 * Read a big integer
 *
 */

int read(Bigint *num){
	if (num == NULL)
        return 1;

    char c = ' ';
    int block;

    while (1) {
        if (scanf("%d%c", &block, &c) != 2){
		if (c == '\n') break; // Re-check c if scanf fails
            	return 1;
	}
	

        if (insert(num->numbers,0,block) == 1)
            return 1;

        if (c == '\n')
            break;
    }

    return 0;
}
