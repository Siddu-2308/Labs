/*
 * Unit testing for the list library
 *
 */

// TODO: Add appropriate header files
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "list.h"
#include "bigint.h"
#define POWNINE 1000000000
// Helper to create a Bigint from a single block
Bigint* create_from_block(int block) {
    Bigint * b = (Bigint*)malloc(sizeof(Bigint));
    if (b == NULL) return NULL;
    initialize(b);
    if (append(b->numbers, block) != 0) {
        free_bigint(b);
        return NULL;
    }
    return b;
}
/*
 * Unit testing for the list library
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "list.h"
#include "bigint.h"

#define POWNINE 1000000000

// --- Helper Functions for Testing ---

// Helper to create a Bigint from a single block
Bigint* create_from_block(int block) {
    Bigint * b = (Bigint*)malloc(sizeof(Bigint));
    if (b == NULL) return NULL;
    initialize(b);
    if (append(b->numbers, block) != 0) {
        free_bigint(b);
        return NULL;
    }
    return b;
}

// Helper to create a Bigint from multiple blocks (LSB first)
Bigint* create_from_blocks(int* blocks, int count) {
    Bigint * b = (Bigint*)malloc(sizeof(Bigint));
    if (b == NULL) return NULL;
    initialize(b);
    for (int i = 0; i < count; i++) {
        if (append(b->numbers, blocks[i]) != 0) {
            free_bigint(b);
            return NULL;
        }
    }
    return b;
}
int testEqual(){

	Bigint * a = malloc(sizeof(Bigint));
        initialize(a);
        append(a->numbers, 100000000);

        Bigint * b = malloc(sizeof(Bigint));
        initialize(b);
        append(b->numbers, 900000000);

	int res = !(equal(a,b) == 0);

	free_bigint(a);
	free_bigint(b);

	return res;
}


int testAdd(){

	// TODO: Complete the function
}

int testRead(){
	Bigint * a = malloc(sizeof(Bigint));
        initialize(a);
	
	int ret1 = read(a);
	print(a);
	printf("\n");

	free_bigint(a);

	return ret1;
}


///////////////////////////////////////
// Do not modify the functions below //
//////////////////////////////////////

int test(){
	int result = 1;

	if(testAdd()){
		printf("\tadd() failed\n");
		result = 0;
	}else{
		printf("add() passed\n");
	}

	if(testEqual()){
		printf("\tequal() failed\n");
		result = 0;
	}else{
		printf("equal() passed\n");
	}

	if(testRead()){
		printf("\tread() failed\n");
		result = 0;
	}else{
		printf("read() passed\n");
	}


	return result;
}



int main(){

	printf("Running all test cases\n\n");
	if(test()){
		printf("\nAll test cases passed\n");
	}else{
		printf("\nSome test cases did not pass\n");
	}

	return 0;
}
