#include <stdio.h>

// TODO Include appopriate headers for dynamic memory allocation


int main(int argc, char** argv){


}


