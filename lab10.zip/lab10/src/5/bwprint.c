#include <stdio.h>

// TODO Include appopriate headers for dynamic memory allocation

struct rbg {
	int r;
	int b;
	int g;
};

typedef struct rbg RBG;
// TODO: Complete the code

int main(int argc, char** argv){


}


