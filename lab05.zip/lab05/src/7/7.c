#include <stdio.h>

int main()
{
	int a=0, b=0;

	//Get an integer from the user
	scanf("%d %d", &a, &b);

	//Do not add/modify anything about this line
	//TODO: Complete the code
	if (a>b){printf("a>b");}
	if (a==b){printf("a=b");}
	if (a<b){printf("a<b");}
	//Do not add/modify anything below this line
	return 0;
}

