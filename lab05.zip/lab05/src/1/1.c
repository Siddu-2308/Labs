#include <stdio.h>

int main()
{
	int a=0, b=0 ;
	int result=0;
	char op;
	//Get two integers and operation from the user
	scanf("%d %d %c", &a, &b, &op);

	//Do not add/modify anything about this line
	//TODO: Complete the code
	if(op=='+'){
		result=a+b;}
	if(op=='-'){
		result=a-b;}
	if(op=='*'){
		result=a*b;}
	
	//Do not add/modify anything below this line
	//Print the maximum value
	printf("%d\n", result);
	return 0;
}

