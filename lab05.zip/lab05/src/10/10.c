#include <stdio.h>

int main()
{
	long long a=0, factor_sum = 0;

	//Read an integer from the user
	scanf("%lld", &a);

	//Do not add/modify anything about this line
	//TODO: Complete the code
	if (a <= 1) {
    		printf("No");
    		return 0;
	}	
	factor_sum = 1;
	long long i;
	for (i = 2; i * i <= a; i++) {
    		if (a % i == 0) {
        		factor_sum += i;
        		if (i != a / i)
            		factor_sum += a / i;
    			}
}
    if (factor_sum == a) {
        printf("Yes");
    } else {
        printf("No");
    }

   

	//Do not add/modify anything below this line
	return 0;
}

