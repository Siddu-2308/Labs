#include <stdio.h>

int main()
{
	int a = 0;

	//Get an integer from the user
	scanf("%d", &a);

	//Do not add/modify anything about this line
	//TODO: Complete the code
	if(a<=0){
		printf("Not power of 3");
		return 0;
	}
	int temp =a;
	while (temp%3==0){
		temp/=3;	}
	if (temp==1){
		printf("Power of 3");
	}
	else{
		printf("Not power of 3");
}


	//Do not add/modify anything below this line
	return 0;
}

