Type 

$ make test.o

The file test.c will be compiled even without any makefile present !
