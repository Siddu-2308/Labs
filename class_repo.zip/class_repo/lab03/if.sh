name="Deepak"

if [[ $name = "IITPKD" ]]
then
	echo "Hello $name"
else
	echo "Bye $name"
fi
