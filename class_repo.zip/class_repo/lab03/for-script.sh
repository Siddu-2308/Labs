for i in $(ls)
do
	echo $i
done
