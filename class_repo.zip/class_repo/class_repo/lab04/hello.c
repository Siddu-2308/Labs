

/*
    The Hello World Program in C
 */

/* C math and I/O libraries */
#include <math.h>
#include <stdio.h>

#define MAX_VALUE 1000

/* main function definition: */
int main(void) {
    // statements end in a semicolon (;)
    printf("Hello World\n");
    printf("sqrt(4) is %f\n", sqrt(4));
    printf("Max value is %d\n", MAX_VALUE);

    return 0;  // main returns value 0
}


