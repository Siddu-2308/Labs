/*
 * Header file for mod function
 */

#ifndef MYMOD_H
#define MYMOD_H

int mod(int,int);

#endif
