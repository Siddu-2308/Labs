/*
 * Header file for myadd function
 */

#ifndef MYADD_H
#define MYADD_H

int add(int x,int y);

#endif
