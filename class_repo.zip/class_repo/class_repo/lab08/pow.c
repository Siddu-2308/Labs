#include <stdio.h>
#include <math.h>

int main(){
  
  int a = 2;
  int b = 9;

  printf("Power is %lf\n", pow(a,b));

  return 0;
}
