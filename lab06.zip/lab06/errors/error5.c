/* Find and fix the errors in the program */

#include<stdio.h>
int main()
{
	int i=5;
	while(i<10)
	{
		printf("%d\n",i);
		i++;
	}
	return 0;
}
