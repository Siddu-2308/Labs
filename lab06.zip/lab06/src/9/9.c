#include <stdio.h>

#define SIZE 100

int main()
{
	char string [SIZE];
	char* ptr = NULL;
	char* head = NULL;

	//Get a string from user
	scanf("%s", string);

	//Do not add/modify anything about this line
	//TODO: Complete the code
	ptr=string;
	head=string;
	while(*ptr !='\0'){ptr++;}
	ptr--;

	int is_palindrome=1;
	while(head<ptr){
	if(*ptr!=*head){is_palindrome=0;break;}
	head++;
        ptr--;
	}
	if (is_palindrome){printf("Palindrome");}
	else{printf("Not palindrome");}



	//Do not add/modify anything below this line
	return 0;
}

