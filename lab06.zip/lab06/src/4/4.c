#include <stdio.h>


int main()
{
	int a=0, octal = 0;

	//Get an integer from the user
	scanf("%d", &a);

	//Do not add/modify anything about this line
	//TODO: Complete the code
	int place =1;
	//octal=octal+((a)&7)*1+((a>>3)&7)*8+((a>>6)&7)*64+((a>>9)&7)*512+((a>>12)&7)*512*8; 
	while (a>0){
		octal+=(a&7)*place;
		a=a>>3;
		place=place*10;}
	//Do not add/modify anything below this line
	printf("%d\n", octal);
	return 0;
}

