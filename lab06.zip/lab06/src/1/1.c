#include <stdio.h>

#define SIZE 10

int main()
{
	unsigned int input;

	/* The hex_str should finally look like "0xPQRS"
	 * where P,Q,R,S are one of {0,..,9,A,..,F}
	 */
	char hex_str [SIZE]; 

	//Get two integers and operation from the user
	scanf("%u", &input);

	//Do not add/modify anything about this line
	//TODO: Complete the code
	char hex_digits[]="0123456789ABCDEF";
	unsigned int shift = 15;
	unsigned int hex3 = input & shift; 
	unsigned int hex4 = (input>>4) & shift;
	unsigned int hex5 = (input>>8) & shift;
	unsigned int hex6 = (input>>12) & shift;
	hex_str[0] = '0';
	hex_str[1] = 'x';
	hex_str[6] = '\0';
	hex_str[2] =hex_digits[hex6];
	hex_str[3] =hex_digits[hex5];
	hex_str[4] = hex_digits[hex4];
	hex_str[5] =hex_digits[hex3];
	//Do not add/modify anything below this line
	//Print the answer
	printf("%s\n", hex_str);
	return 0;  
}

