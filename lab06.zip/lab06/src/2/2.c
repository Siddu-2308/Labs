#include <stdio.h>

#define SIZE 7

int main()
{
	char input [SIZE];
	int result;

	//Get two floating point values from the user
	scanf("%s", input);

	//Do not add/modify anything about this line
	//TODO: Complete the code
	// START
	int val0 = 0, val1 = 0, val2 = 0, val3 = 0;

	if (input[2]){
		val0 = (input[2] >= 'A') ? 10+(input[2] - 'A') : (input[2] - '0');
	}
	if (input[3]){
		val1 = (input[3] >= 'A') ? 10+(input[3] - 'A') : (input[3] - '0');
	}
	if (input[4]){
		val2 = (input[4] >= 'A') ? 10+(input[4] - 'A') : (input[4] - '0');
	}
	if (input[5]){
		val3 = (input[5] >= 'A') ? 10+(input[5] - 'A') : (input[5] - '0');
	}

	result = val3 + (val2<<4) + (val1<<8) + (val0<<12);
	
	// END
	//Do not add/modify anything below this line
	printf("%d\n", result);
	return 0;
}

