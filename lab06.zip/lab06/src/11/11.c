#include <stdio.h>

int main()
{
	int value;

	//Read an integer from the user
	scanf("%d", &value);

	//Do not add/modify anything about this line
	//TODO: Complete the code
	int tri[1000];
	int k=0;
	tri[k++]=0;
	for (int i=1; ;i++){
	int t= i* (i+1) /2;
	if (t>value) break;
	tri[k++]=t;
	}	
	for (int r=0; ;r++){
		int printed=0;
		for (int c=0;c<k;c++){
		int val=tri[c] +r *(c+2) +(r*(r-1))/2;
		if (val <=value){
		if (printed) printf(" ");
		printf("%d",val);
		printed =1;
		}
	}
	if(printed){
		printf("\n");
	}
	else{
		break;}
		


}
	//Do not add/modify anything below this line
	return 0;
}
