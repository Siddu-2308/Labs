#include <stdio.h>

#define ROWS 3
#define COLS 3

int main()
{
	int mat1[ROWS][COLS]={0};
	int mat2[ROWS][COLS]={0};
	int mat3[ROWS][COLS]={0};
	int tmp;

	//Do not add/modify anything about this line
	//TODO: Complete the code
	for(int i=0;i<ROWS;i++){
	for(int j=0;j<COLS;j++){
		scanf("%d",&mat1[i][j]);}}
	for(int i=0;i<ROWS;i++){
        for(int j=0;j<COLS;j++){
                scanf("%d",&mat2[i][j]);}}		
	
	for(int i=0;i<ROWS;i++){
        for(int j=0;j<COLS;j++){tmp=0;
             while(tmp<3){
		mat3[i][j]+=mat1[i][tmp]*mat2[tmp][j];tmp++;}
			}}
	for(int i=0;i<ROWS;i++){
        for(int j=0;j<COLS;j++){
                printf("%d ",mat3[j][i]);}printf("\n");}
	//Do not add/modify anything below this line
	return 0;
}

