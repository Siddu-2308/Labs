#include <stdio.h>
#include <stdlib.h>

int main()
{
	long a,b,temp=0 ;

	//Get two integers from the user
	scanf("%ld %ld", &a, &b);

	//Do not add/modify anything about this line
	//TODO: Complete the code

	// START
	
	while (b > 0) {
		// Swap a and b if b is larger
		if (a < b) {
			temp = a;
			a = b;
			b = temp;
		}
		int arg1 = b;
		int arg2 = a % b;
		a = arg1;
		b = arg2;
	}
	printf("%ld\n",abs(a));

	// END	
	
	//Do not add/modify anything below this line
	return 0;
}
