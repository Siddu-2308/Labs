// TODO: Include appropriate headers

unsigned int inner_product(Ivector* v1, Ivector* v2, int* invalid){  
  // TODO: Complete the code
}


Ivector* add(Ivector* v1, Ivector* v2){
  // TODO: Complete the code
}


Ivector* scalarmult(Ivector* v, unsigned int c){
  // TODO: Complete the code
}

void print(Ivector* v){
  // TODO: Complete the code
}

