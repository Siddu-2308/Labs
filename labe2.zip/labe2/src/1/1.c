#include <stdio.h>

// TODO: Add appropriate headers



int main()
{

	//TODO: Complete the code
	


	//Do not add/modify anything below this line

        return 0;
}

