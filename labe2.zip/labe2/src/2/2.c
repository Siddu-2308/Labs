#include <stdio.h>

// TODO: Add appropriate headers


// TODO: Write the encryption() function

void encryption(char* message, int key){
}



// TODO: Write the decryption() function

void decryption(char* message, int key){

}

int main()
{
        // TODO Complete the code below

	//TODO: prevent memory leaks
	
	
        // Do not modify any line below
	return 0;
}
