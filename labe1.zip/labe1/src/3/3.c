#include <stdio.h>

int main()
{

	//Get an integer from the user
	//TODO: Complete the code
	unsigned long a;
	scanf("%ld",&a);
	while(a!=1){
		if(a%2==0){printf("%ld ",a);a=a/2;}
		else{printf("%ld ",a);a=a*3+1;} 
	}
	printf("1");
	//Do not add/modify anything below this line
	return 0;
}

