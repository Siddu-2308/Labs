#include <stdio.h>

#define SIZE 5

int main()
{
	char input[SIZE];
	int result;
		
	// Read the input
	scanf("%s", input);

	//Do not add/modify anything above this line
	//TODO: Complete the code
	if(input[0]==input[1]==input[2]==input[3]==input[4]==input[5]){printf("Invalid"); }
	else{ //sorting
			char x[SIZE];
			for(int i=0;i<SIZE;i++){
			for(int j=i+1;j<SIZE;j++){
			if ((int)input[i]>=(int)input[j]){char t=input[i];input[i]=input[j];input[j]=t;}	}}

	//Do not add/modify anything below this line
	//Print the answer
	printf("%d\n", result);
	return 0;
}

