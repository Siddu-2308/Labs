#include <stdio.h>

#define ROWS 4
#define COLS 4

int main()
{
	int matrix[ROWS][COLS];

	//Do not add/modify anything about this line
	//TODO: Complete the code
	for (int i=0;i<ROWS;i++){
	for (int j=0;j<COLS;j++){
		scanf("%d",&matrix[i][j]);}}
	int transpose[ROWS][COLS]={0};
	for (int i=0;i<ROWS;i++){
	for (int j=0;j<COLS;j++){
		transpose[i][j]=matrix[j][i];}}
	for (int i=0;i<ROWS;i++){
	for (int j=0;j<COLS;j++){
		printf("%d ",transpose[i][j]);}printf("\n");}
	//Do not add/modify anything below this line
	return 0;
}

