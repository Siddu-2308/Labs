# Instructions (Mock Quiz)

* Each folder has a .c file with the same name as the folder, a `test` directory
  and a `makefile`. The .c file already contains the necessary instructions to
  fill it. In particular, modify only the parts mentioned in the file.

* Read the question number i below and start editing the i.c file in folder i.
  That is, question number 1 needs to answered in `1/1.c`, question number 2
  needs to be answered in `2/2.c` and so on.

* You can compile the .c file by running `$ make`. Any errors/warnings will be
  displayed here. You must change the .c file so that no errors or warning is
  displayed.

* You are also encouraged to inspect the output of program using `hexdump` to see 
  if any stray/unprintable characters are being printed.  An example usage (for
  program named `6`) is as follows:

  ``` bash
  # To see if any extra characters are printed
  $ ./6 < tests/test1.in | hexdump  
  # To view the same in human readable form
  $ ./6 < tests/test1.in | hexdump -c
  ```

* To test your program, cd to the directory for the question and run `$ make
  tests`. It will show which all test cases passed and which all failed.

* Repeat the above till all the test cases have passed. Then, move on to the
  next question.

* Once you have finished with the questions, head to the section on Error
  codes, where you are expected to find bugs in the program.

* If you have finished all of it, there are some exercises at the end of this
  document to complete.

# Questions

1. Write a C program that answers the Ultimate Question of Life, the Universe
   and Everything. (Hint: Just print 42)

2. Write a C program that takes an integer and print the first three
   significant digits of the hexadecimal representation. NOTE: You are not
   allowed to used the * operators, or pow() function.

