#include <stdio.h>

#define SIZE 7

int main()
{
	int result, input;

	//Get two floating point values from the user
	scanf("%d", &input);
	//Do not add/modify anything about this line
	//TODO: Complete the code
	result=42;

	//Do not add/modify anything below this line
	printf("%d\n", result);
	return 0;
}

