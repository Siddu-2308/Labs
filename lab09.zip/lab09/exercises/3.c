#include <stdio.h>

// Function that takes two integer pointers and swap the contents using
// bitwise operation alone without using any extra variables
void swap(int* x, int* y){
// TODO: Complete the function

}

int main(){
	int x = 100;
	int y = 200;

	swap(&x,&y);

	printf("%d %d", x, y);
	return 0;
}
