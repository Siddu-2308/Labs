#include <stdio.h>

#define TRUE  1
#define FALSE 0

int function_returning_false() {return FALSE;}

int main() {
  if (function_returning_false) {
    printf("function returned true\n");
  }
}

