#include <stdio.h>

unsigned int i;

int main() {
  for (i = 4; i >= 0; i--) {
    printf("i = %d\n", i);
  }
}

