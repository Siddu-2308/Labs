#include <stdio.h>

int main() {
  int i;
  for (i = 0; i < 42; i++);
    {
      printf("i = %d\n", i);
    }
}

