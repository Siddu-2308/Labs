#include <stdio.h>

// TODO: Implement the binary tree, and the interactive traversal of the tree
/*
           2
         /   \
        7     9
       /     / \
      15    11  13
     /  \
    18  20
*/

#include <stdlib.h>

struct tree_node {
    int data;
    struct tree_node* left_child;
    struct tree_node* right_child;
    struct tree_node* parent;
};

struct tree_node* create(int data) {
    struct tree_node* node = malloc(sizeof(struct tree_node));
    node->data = data;
    node->left_child = NULL;
    node->right_child = NULL;
    node->parent = NULL;
    return node;
}

struct tree_node* build_sample_tree() {
    struct tree_node* n2  = create(2);
    struct tree_node* n7  = create(7);
    struct tree_node* n9  = create(9);
    struct tree_node* n15 = create(15);
    struct tree_node* n11 = create(11);
    struct tree_node* n13 = create(13);
    struct tree_node* n18 = create(18);
    struct tree_node* n20 = create(20);

    n2->left_child = n7;
    n2->right_child = n9;
    n7->parent = n2;
    n9->parent = n2;

    n7->left_child = n15;
    n15->parent = n7;

    n9->left_child = n11;
    n9->right_child = n13;
    n11->parent = n9;
    n13->parent = n9;

    n15->left_child = n18;
    n15->right_child = n20;
    n18->parent = n15;
    n20->parent = n15;

    return n2;
}

void interactive_traversal(struct tree_node* root) {
    if (!root) {
        printf("Tree is empty.\n");
        return;
    }
    struct tree_node* ptr = root;
    char op[2];
    do {
        printf("\nYou are at node %d\n", ptr->data);
        printf("Options: l (left), r (right), p (parent), q (quit)\n");
        if (ptr->left_child)  printf("  Left child: %d\n", ptr->left_child->data);
        if (ptr->right_child) printf("  Right child: %d\n", ptr->right_child->data);
        if (ptr->parent)      printf("  Parent: %d\n", ptr->parent->data);

        printf("Enter option: ");
        scanf("%s", op);

        switch (op[0]) {
            case 'l':
                if (ptr->left_child)
                    ptr = ptr->left_child;
                else
                    printf("No left child!\n");
                break;
            case 'r':
                if (ptr->right_child)
                    ptr = ptr->right_child;
                else
                    printf("No right child!\n");
                break;
            case 'p':
                if (ptr->parent)
                    ptr = ptr->parent;
                else
                    printf("No parent!\n");
                break;
            case 'q':
                printf("Exiting interactive traversal.\n");
                break;
            default:
                printf("Invalid input. Valid options are l, r, p, q\n");
        }
    } while (op[0] != 'q');
}

int main() {
    struct tree_node* root = build_sample_tree();
    interactive_traversal(root);
    return 0;
}

