#include <stdio.h>
//TODO: Include appropriate header file for dynamic memory allocation
#include <stdlib.h>
#define MOD 101010

int main()
{
	int n;
        int result = 1;

	//Get the order of the tensor from the user
	scanf("%d", &n);

	//Do not add/modify anything about this line
	//TODO: Complete the code
    int ***tensor = (int ***)malloc(n * sizeof(int **));
    if (tensor == NULL) {
        printf("Memory allocation failed.\n");
        return 1;
    }

    for (int i = 0; i < n; i++) {
        tensor[i] = (int **)malloc(n * sizeof(int *));
        for (int j = 0; j < n; j++) {
            tensor[i][j] = (int *)malloc(n * sizeof(int));
        }
    }
	
	 for (int i = 0; i < n; i++) {          // depth (layers)
        for (int j = 0; j < n; j++) {      // rows
            for (int k = 0; k < n; k++) {  // columns
                scanf("%d", &tensor[i][j][k]);
            }
        }
    }

	  for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < n; k++) {
                result = (result * (tensor[i][j][k] % MOD)) % MOD;
            }
        }
    }





        printf("%d\n", result);

	//TODO: DO NOT FORGET TO FREE ANY MEMORY ALLOCATED USING malloc() using
	// free() 
	// Free allocated memory
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            free(tensor[i][j]);
        }
        free(tensor[i]);
    }
    free(tensor);
	//Do not add/modify anything below this line
	return 0;
}

