#include <stdio.h>
//TODO: Answer question 6 here

